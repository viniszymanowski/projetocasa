# Ficha do Terreno

- Localização:
- Dimensões (frente x fundos):
- Área total (m²):
- Declividade aproximada:
- Confrontantes:
- Observações gerais:
