# Dimensões do Terreno

## Medidas Principais

| Elemento | Medida (metros) |
|----------|-----------------|
| Frente (testada) | [A preencher] |
| Fundos | [A preencher] |
| Lateral direita | [A preencher] |
| Lateral esquerda | [A preencher] |
| **Área total** | **[__] m²** |

## Formato do Lote
- [ ] Retangular
- [ ] Trapezoidal  
- [ ] Irregular

## Topografia
- **Declividade:** [Plano / Aclive / Declive]
- **Desnível aproximado:** [__] metros

## Observações
[Adicionar informações relevantes sobre dimensões e características físicas]
