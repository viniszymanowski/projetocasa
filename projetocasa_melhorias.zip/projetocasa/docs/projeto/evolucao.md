# Evolução do Projeto

Use este arquivo para registrar marcos importantes, versões de planta, grandes decisões e mudanças de rumo.
