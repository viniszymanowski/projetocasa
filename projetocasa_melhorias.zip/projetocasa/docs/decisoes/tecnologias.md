# Decisões – Tecnologia

## Automação
- Iluminação inteligente  
- Fechaduras eletrônicas  
- Controle por voz (Alexa/Google)  
- Sensores de presença  

## Segurança
- Câmeras externas  
- WiFi mesh  
- Porteiro eletrônico  

## Conforto
- Som ambiente  
- Ar-condicionado preparado para automação  
- Preparação para painel solar  
- Aquecimento solar/boiler  

## Infraestrutura
- Tubulações preparadas para automação desde o início  
- Quadro de rede dedicado  
- Cabeamento estruturado  
