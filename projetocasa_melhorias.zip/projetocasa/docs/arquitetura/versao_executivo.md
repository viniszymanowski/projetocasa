# Versão Executivo
## Descrição
Versão final aprovada do projeto arquitetônico com todas as cotas e detalhes técnicos.

## Itens obrigatórios
- Plantas baixas completas
- Cortes e fachadas
- Pontos elétricos e hidráulicos
- Lista de materiais principais
