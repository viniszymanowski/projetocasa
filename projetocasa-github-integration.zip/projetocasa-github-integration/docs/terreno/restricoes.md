# Restrições
