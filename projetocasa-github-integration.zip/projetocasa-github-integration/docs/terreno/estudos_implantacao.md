# Estudos de Implantação

- Orientação solar
- Ventos predominantes
- Vistas a aproveitar
- Vizinhança imediata
- Restrições e oportunidades
