# Fotos do Terreno

Estas são as fotos de referência do terreno. Clique nas imagens para ampliá-las.

<a href="/projetocasa/data/Fotos/terreno-frente.jpg" data-lightbox="terreno" data-title="Vista frontal do terreno">
  <img src="/projetocasa/data/Fotos/terreno-frente.jpg" alt="Terreno – vista frontal" width="300px" style="margin:10px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.15);">
</a>

<a href="/projetocasa/data/Fotos/terreno-modelo.jpg" data-lightbox="terreno" data-title="Vista geral do terreno">
  <img src="/projetocasa/data/Fotos/terreno-modelo.jpg" alt="Terreno – vista modelo" width="300px" style="margin:10px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.15);">
</a>
