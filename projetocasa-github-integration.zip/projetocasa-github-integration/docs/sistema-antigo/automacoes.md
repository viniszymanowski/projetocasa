# Automações Planejadas

Registrar scripts, planilhas ou integrações (GitHub Actions, Python, etc.) que serão criados para o projeto.
