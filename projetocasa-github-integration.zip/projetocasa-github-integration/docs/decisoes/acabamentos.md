# Decisões – Acabamentos

## Prioridades
1. Durabilidade  
2. Facilidade de limpeza  
3. Design  

## Fachada
- Textura acrílica (cinza)  
- Porcelanato técnico  
- Ripados sintéticos amadeirados  
- Esquadrias pretas  

## Pisos
- Porcelanato grande em áreas sociais  
- Vinílico em quartos  
- Porcelanato antiderrapante em áreas molhadas  

## Revestimentos
- Grandes formatos  
- Nichos nos banheiros  
- Iluminação embutida  

## Mobiliário e Detalhes
- Portas pretas ou brancas lisas  
- Perfil LED em cozinha e hall  
- Guarda-corpos e corrimãos minimalistas  
