# Decisões – Ambientes

## Ambientes Obrigatórios
- 2 Quartos  
- 1 Suíte  
- Escritório  
- Sala  
- Cozinha  
- Cozinha Gourmet (separada)  
- Lavanderia  
- Depósito  
- Despensa  
- 3 Banheiros  
- Garagem para 2 camionetes  
- Canil e Gatil  
- Churrasqueira  

## Ambientes Desejáveis
- Piscina  
- Salão de jogos (sinuca, karaokê, bar)  
- Oficina  
- Área verde para pets  

## Observações Gerais
- Evitar integração total de ambientes  
- Pensar em circulações amplas  
- Layout com privacidade nos dormitórios  
