# Conceito Inicial
## Objetivo
Descrever as ideias, referências visuais, estilo arquitetônico e principais objetivos do projeto.

## Itens a documentar
- Estilo desejado (moderno, rústico, minimalista, etc.)
- Volumetria preliminar
- Relação entre ambientes
- Diretrizes de conforto térmico e iluminação
- Inspirações e imagens de referência
