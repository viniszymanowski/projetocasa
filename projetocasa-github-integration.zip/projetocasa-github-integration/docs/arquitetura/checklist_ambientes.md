# Checklist de Ambientes
## Itens a verificar em cada cômodo
| Ambiente | Iluminação natural | Ventilação | Tomadas | Revestimentos | Observações |
|-----------|--------------------|-------------|----------|----------------|--------------|
| Sala de estar | ☐ | ☐ | ☐ | ☐ |  |
| Cozinha | ☐ | ☐ | ☐ | ☐ |  |
| Suíte | ☐ | ☐ | ☐ | ☐ |  |
| Área gourmet | ☐ | ☐ | ☐ | ☐ |  |
| Banheiro | ☐ | ☐ | ☐ | ☐ |  |
