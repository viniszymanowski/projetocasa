# Versão Pré-Executivo
## Layout preliminar
Representação inicial do layout com medidas aproximadas e relação entre ambientes.

## Observações
- Utilizada para simular conformidade com normas (recuos, taxa de ocupação, altura).
- Pode ser usada como base para o validador automático de conformidade.
