# Rotina do Casal

Descrever horários típicos, usos principais da casa, hábitos (trabalho, lazer, hobbies, animais, etc.).
