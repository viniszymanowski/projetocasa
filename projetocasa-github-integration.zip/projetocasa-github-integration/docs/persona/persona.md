# Persona do Projeto

## Perfil dos Moradores

### Composição Familiar
- **Número de moradores:** [A preencher]
- **Faixa etária:** [A preencher]
- **Pets:** [A preencher]
- **Previsão de crescimento familiar:** [A preencher]

### Estilo de Vida

#### Rotina Profissional
- **Trabalho:** [Presencial / Híbrido / Home office]
- **Horários:** [A preencher]
- **Necessidade de home office:** [Sim / Não]
- **Quantidade de pessoas em home office:** [A preencher]

#### Hábitos e Preferências
- **Receber visitas:** [Frequentemente / Ocasionalmente / Raramente]
- **Tipo de eventos:** [Churrascos / Jantares / Festas / Outros]
- **Hobbies e atividades:** [A preencher]
- **Prática de exercícios em casa:** [Sim / Não]

### Valores e Prioridades

#### O que é mais importante para vocês?
- [ ] Conforto térmico e ventilação natural
- [ ] Iluminação natural abundante
- [ ] Privacidade
- [ ] Integração com área externa
- [ ] Espaços amplos e integrados
- [ ] Muitos ambientes separados
- [ ] Facilidade de manutenção
- [ ] Sustentabilidade e eficiência energética
- [ ] Tecnologia e automação
- [ ] Segurança

#### Estilo Arquitetônico Preferido
- **Referências visuais:** [Moderno / Contemporâneo / Rústico / Industrial / Minimalista / Outro]
- **Cores predominantes:** [A preencher]
- **Materiais preferidos:** [Madeira / Concreto / Vidro / Pedra / Outros]

## Visão do "Lar Ideal"

### Como vocês imaginam a casa dos sonhos?
[Descrever em texto livre como seria o dia a dia ideal nesta casa, quais sensações ela deve transmitir, como os espaços devem se conectar, etc.]

### Ambientes Essenciais
[Listar os ambientes que são absolutamente necessários]

### Ambientes Desejáveis
[Listar os ambientes que seriam bons de ter, mas não são críticos]

### O que NÃO querem na casa?
[Listar características, ambientes ou soluções que devem ser evitadas]

## Inspirações e Referências

### Casas ou projetos que admiram
[Links, fotos ou descrições de projetos que servem de inspiração]

### Elementos específicos que gostariam de incorporar
[Ex: "Aquela varanda integrada com a sala", "Cozinha com ilha central", etc.]

---

*Este documento serve como base para todas as decisões arquitetônicas do projeto. Deve ser revisado e atualizado conforme as conversas e decisões evoluem.*
