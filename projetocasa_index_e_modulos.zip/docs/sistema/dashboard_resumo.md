# Dashboard - Resumo do Projeto (Plano Futuro)

Ideias para indicadores:
- Status de cada módulo
- Custos estimados x realizados
- Alertas de não conformidade
