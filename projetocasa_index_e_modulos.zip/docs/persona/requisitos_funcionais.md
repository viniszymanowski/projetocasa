# Requisitos Funcionais da Casa

Liste as necessidades derivadas da rotina (ex.: home office silencioso, área gourmet, espaço para ferramentas, etc.).
